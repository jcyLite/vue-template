import Thank from './src'
export default Thank;
