<template>
	<div class="tk-nodata">
		
	</div>
</template>

<script>
</script>

<style lang="less">
	.tk-nodata{
		background-image:url('./nodata.png');
		height:100px;
		background-size:contain;
		background-repeat: no-repeat;
		width:100px;
		left:0;
		right:0;
		margin:auto;
	}
</style>