import Sign from './Sign/Sign.vue';
export default{
	Sign
}