import Header from './Header/Header.vue';
import Button from './Button/Button.vue';
import Button_Group from './Button_Group/Button_Group.vue';
import Container from './Container/Container.vue';
import Cell from './Cell/Cell.vue'
export default{
	Header,Cell,Button,Container,Button_Group
}
