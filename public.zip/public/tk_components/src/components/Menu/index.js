import Accordion from './Accordion/Accordion.vue';
export default {
	Accordion
}
