import Switch from './Switch/Switch.vue'
import Switch_Cell from './Switch_Cell/Switch_Cell.vue'
export default {
	Switch,Switch_Cell
}
