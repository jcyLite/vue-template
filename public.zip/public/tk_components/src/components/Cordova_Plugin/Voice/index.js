import {createFile} from '../../JsModule/file.js';
export default function voice(){
	
}
