###Welcome to use MarkDown
props:{
	scroll:{
		type:Boolean,
		default:true
	},
	height:{
		type:[String,Number],
		default:300
	},
	maskClickAble:{
		type:Boolean,
		default:true
	}
}
this.$createTkPopMiddle({

}).show()
