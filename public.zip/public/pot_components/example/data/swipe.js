export const defaultData = [{
  item: {
    text: '测试1',
    value: 1
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试2',
    value: 2
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试3',
    value: 3
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 4
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 5
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 6
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 7
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 8
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 9
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 10
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 11
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 12
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 13
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 14
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 15
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 16
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 17
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 18
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 19
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 20
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 21
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 22
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 23
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}, {
  item: {
    text: '测试',
    value: 24
  },
  btns: [
    {
      action: 'clear',
      text: '不再关注',
      color: '#c8c7cd'
    },
    {
      action: 'delete',
      text: '删除',
      color: '#ff3a32'
    }
  ]
}]

export const customData = [
  {
    item: {
      id: '3646653877',
      name: '还不是因为你长得不好看',
      desc: '伤感：歌词再狠，也抵不过现实伤人',
      imgurl: 'http://p.qpic.cn/music_cover/MhQ4bJBPt3Yt5icXyBGNhyPJnE9O51CqaN72iaDgvFmDKaia12UFhU5uQ/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '1789676645',
      name: '秋水浮萍任飘渺',
      desc: '『武侠配乐』快意恩仇江湖情',
      imgurl: 'http://p.qpic.cn/music_cover/8KfvDey9cibtZ5xkWxRic6vhXgdPic3wnB7reibI4pdPQBCP8u57uqcjsQ/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '3649034125',
      name: '念葳蕊',
      desc: '江海迦：热恋后哼一首歌为自己悲悯的歌',
      imgurl: 'http://p.qpic.cn/music_cover/jXFicBvicUcfIWSoCNT1OrbAoHG2fqqnrJVnGV4iaLCapWUpCKqbmAicJg/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '2977781451',
      name: '风少',
      desc: '午后甜点：静听浓情爵士，于悠然中尽享',
      imgurl: 'http://p.qpic.cn/music_cover/llTQ9l2AeicK2OLIORnsUdtbhlNRGF89NBDI6SoBxEIzhAlrmV1SmGg/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '2691498608',
      name: '虛榮少女',
      desc: '感性强盗｜强势洗榜的那些韩国抒情音乐',
      imgurl: 'http://p.qpic.cn/music_cover/icLTHicH8iakBFAJbiazGT3DnywHfOoiaVzdZWJ4pVcDdoVCqlU5hLx8K7A/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '3703029362',
      name: '哔咯独角兽',
      desc: '温情摇滚｜安抚夜色弥漫时落寞的心',
      imgurl: 'http://p.qpic.cn/music_cover/0yiaX8d9LSmnROyId1RsUUwklzSKKp7RSanBAJ89We5I4kMwdnH5yeg/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '3606666961',
      name: '毕业雨季',
      desc: '小资情调：何为亏欠文艺青年心中的体面',
      imgurl: 'http://p.qpic.cn/music_cover/SXTicaprnQbfAyiaibTsguPlPQK4ZBwicp09O22qKwnTJaO10kp2le37Ww/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '3604823742',
      name: '冷门单曲酱',
      desc: '放假挤火车回家：等车时的轻快曲',
      imgurl: 'http://p.qpic.cn/music_cover/lricrZ3ca62ybvZbWYjtYa9d3Biab7MTiaJhX9owcjdkv5HMxDEunm7tg/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '1746389460',
      name: '私に闻いて风i',
      desc: '追忆续篇：少女漫中关于邂逅他的故事',
      imgurl: 'http://p.qpic.cn/music_cover/qH8rLHHhL8O8Iibm56uPzJy4mNzibugoib19FAujo6GdTXAAvhicw7Js0Q/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '1746020155',
      name: '同位',
      desc: '优雅的音乐贵族 大提琴',
      imgurl: 'http://p.qpic.cn/music_cover/e4us58fDgLVdxdbgmSUdTADM7Sl88AfGK3qQqibxmqpqRnmSGHaFaEQ/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '2949232733',
      name: '香草拿铁',
      desc: '超级碗中场秀嘉宾歌曲集',
      imgurl: 'http://p.qpic.cn/music_cover/V34Wl85ZuJRskg3Ds3R8yyddp8gI2icb7wXicN8ZEzJZP0icnwHyzNzhQ/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '3691421503',
      name: 'L岺',
      desc: '寒假赖床指南:吸猫！吸猫！吸猫！',
      imgurl: 'http://p.qpic.cn/music_cover/Ay2w92PeiaO57pZWMwecv6SEWibhUAoWKzkmWgbtcfCsibQYt8bZtq2PA/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  },
  {
    item: {
      id: '2072789141',
      name: 'D.Va',
      desc: '中国风电音：敢问上天，是否有仙？',
      imgurl: 'http://p.qpic.cn/music_cover/QlZibnBVmII60BjTttickJO9MTQDoTRFvboeks5LDkOJHNEjao8f9t6Q/600?n=1'
    },
    btns: [
      {
        action: 'clear',
        text: '不再关注',
        color: '#c8c7cd'
      },
      {
        action: 'delete',
        text: '删除',
        color: '#ff3a32'
      }
    ]
  }
]
