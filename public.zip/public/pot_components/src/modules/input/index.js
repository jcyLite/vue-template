import Input from '../../components/input/input.vue'

Input.install = function (Vue) {
  Vue.component(Input.name, Input)
}

export default Input
