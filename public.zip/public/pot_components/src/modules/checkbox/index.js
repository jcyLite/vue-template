import Checkbox from '../../components/checkbox/checkbox.vue'

Checkbox.install = function (Vue) {
  Vue.component(Checkbox.name, Checkbox)
}

export default Checkbox
