import Locale from '../../common/locale'

export default Locale
