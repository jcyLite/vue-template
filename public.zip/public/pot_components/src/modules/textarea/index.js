import Textarea from '../../components/textarea/textarea.vue'

Textarea.install = function (Vue) {
  Vue.component(Textarea.name, Textarea)
}

export default Textarea
