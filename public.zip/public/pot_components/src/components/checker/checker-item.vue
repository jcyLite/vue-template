<template>
  <li
    class="pot-checker-item"
    :class="{'pot-checker-item_active': isActive}"
    @click="clickHandler"
  >
    <slot>
      <span v-html="option.text"></span>
    </slot>
  </li>
</template>
<script type="text/ecmascript-6">
  const COMPONENT_NAME = 'pot-checker-item'

  export default {
    name: COMPONENT_NAME,
    props: {
      option: {
        type: Object,
        default() {
          /* istanbul ignore next */
          return {}
        }
      }
    },
    computed: {
      isActive() {
        const isRadio = this.$parent.isRadio
        const currentValue = this.$parent.currentValue
        const value = this.option.value
        return isRadio ? currentValue === value : currentValue.indexOf(value) >= 0
      }
    },
    methods: {
      clickHandler() {
        this.$parent.check(this.option)
      }
    }
  }
</script>
<style lang="stylus" rel="stylesheet/stylus">
  @require "../../common/stylus/variable.styl"
  @require "../../common/stylus/mixin.styl"
  .pot-checker-item
    display: inline-block
    vertical-align: top
    text-align: center
    padding: 8px 10px
    margin-right: 10px
    color: $checker-item-color
    background: $checker-item-bgc
    border-radius: 4px
    border-1px($checker-item-bdc, 4px)
  .pot-checker-item_active
    color: $checker-item-active-color
    background: $checker-item-active-bgc
    border-1px($checker-item-active-bdc, 4px)

</style>
